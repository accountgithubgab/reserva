<!DOCTYPE html>

<script>
    const session =
</script>
<?php

if ($session === 1){
    $start = true;

}else{
    $start = false;

}if($start === true){
    session_start();
}



?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../css/fontawesome/css/all.css">
    <link rel="shortcut icon" href="../img/logo.png"/>
    <title>RESERVA</title>
    <!--
    <script src="./js/angular/angular.js"></script>
    <script>
        angular.module("CadClientes", []);
        angular.module("CadClientes").controller("CadClientesCtrl", function ($scope) {
            $scope.app = "Cadastro de Clientes";
            $scope.clientes = [

            ];


            $scope.tipoClientes = [
                {tipo: "Pessoa Física", codigo: "10"},
                {tipo: "Pessoa Jurídica", codigo: "20"},
                {tipo: "Colaborador", codigo: "30"}
            ];


            $scope.adicionarCliente = function (cliente) {
                $scope.clientes.push(angular.copy(cliente));
                delete $scope.cliente;

            };

            $scope.apagarClientes = function (clientes) {
                $scope.clientes = clientes.filter(function (cliente) {
                    if (!cliente.selecionado) return cliente;
                });
            };

            $scope.temclienteSelecionado = function (clientes) {
                return clientes.some(function (cliente) {
                    return cliente.selecionado;
                });
            };


            $scope.classe1 = "selecionado";
            $scope.classe1 = "negrito";
        });
    </script>
    -->
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content"
            aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <a class="navbar-brand text-white" href="index.html">Reservex&nbsp;<i class="fas fa-desktop text-white"></i></a>
    <!-- Links -->
    <div class="collapse navbar-collapse justify-content-end" id="nav-content">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="../root/companys.php" class="btn text-warning"><i class="far fa-address-card"></i></a>
                <a href="../internal/admin.php" class="btn text-white"><i class="fas fa-building"></i></a>
                <a href="../internal/account.php" class="btn text-white"><i class="fas fa-users-cog"></i></a>
                <a href="../index.php" class="btn text-white"><?php session_destroy() ?><i class="fas fa-sign-out-alt"></i></a>
                <a href="../internal/addNewReserve.php" class="btn btn-success text-white"><i class="fas fa-plus"></i></a>
            </li>
        </ul>
    </div>
</nav>
<!-- Fim da navbar -->
<!--tabela-->
<div class="card mt-4 ml-5 mr-5">
    <div class="card-header"><b>Salas alocadas</b></div>
    <div class="card-body">
        <input class="form-control col-md-6" ng-model="Buscar" placeholder="Filtrar por sala">
        <!--
        <table ng-show="clientes.length > 0" class="table mt-4 ">
            <tr>
                <td></td>
                <td><b>Nome</b></td>
                <td><b>Código</b></td>
                <td><b>Classificação</b></td>
                <td><b>Código da classificação</b></td>
            </tr>
            <tr ng-class="{selecionado: cliente.selecionado, negrito: cliente.selecionado}" ng-repeat="cliente in clientes | filter:Buscar |orderBy: 'nome'">
                <td><input type="checkbox" ng-model="cliente.selecionado"></td>
                <td>{{cliente.nome | uppercase}}</td>
                <td>{{cliente.codigo}}</td>
                <td>{{cliente.tipoClientes.tipo}}</td>
                <td>{{cliente.tipoClientes.codigo}}   </td>
            </tr>
        </table>

-->
    </div>
</div>



</body>
</html>