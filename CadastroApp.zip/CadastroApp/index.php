<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="css/fontawesome/css/all.css">
    <link rel="shortcut icon" href="./img/logo.png"/>
    <link rel="stylesheet" href="css/index.css">
    <title>RESERVA</title>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <a class="navbar-brand text-white" href="index.php">Reservex&nbsp;<i class="fas fa-desktop text-white"></i></a>
    <!-- Links -->
    <div class="collapse navbar-collapse justify-content-end" id="nav-content">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class=" btn btn-outline-secondary nav-link text-white" href="preLogin/login.php">Entrar</a>
            </li>
        </ul>
    </div>
</nav>
<!-- body -->
<div class="form-group border-0 col-md-11 mt-5 ml-5 text-dark text-center font-weight-bold">
    Sua instituição
    precisa de uma forma de organizar melhor sua agenda?
</div>
<!-- Footer -->
<footer class="align-bottom fixed-bottom font-small bg-dark text-white">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3"> 2019 © Copyright -
        <a href="#" class="text-white">Reservex</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
</body>
</html>