<?php require_once ('../session.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../css/indexInternal.css">
    <link rel="stylesheet" href="../css/fontawesome/css/all.css">
    <link rel="shortcut icon" href="../img/logo.png"/>
    <script src='../js/indexInternal.js'></script>
    <link href='../fullcalendar/packages/core/main.css' rel='stylesheet' />
    <link href='../fullcalendar/packages/daygrid/main.css' rel='stylesheet' />
    <script src='../fullcalendar/packages/core/main.js'></script>
    <script src='../fullcalendar/packages/daygrid/main.js'></script>
    <title>RESERVA</title>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-light bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content"
            aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Brand -->
    <a class="navbar-brand text-white" href="   indexInternal.php">Reservex&nbsp;<i class="fas fa-desktop text-white"></i></a>
    <!-- Links -->
    <div class="collapse navbar-collapse justify-content-end" id="nav-content">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="../root/companys.php" class="btn text-warning"><i class="far fa-address-card"></i></a>
                <a href="../internal/admin.php" class="btn text-white"><i class="fas fa-building"></i></a>
                <a href="../internal/account.php" class="btn text-white"><i class="fas fa-users-cog"></i></a>
                <a href="../index.php" class="btn text-white"><i class="fas fa-sign-out-alt"></i></a>
                <a href="../internal/addNewReserve.php" class="btn btn-success text-white"><i class="fas fa-plus"></i></a>
            </li>
        </ul>
    </div>
</nav>
<!-- Fim da navbar -->
<!--tabela-->
<div class="card mt-4 ml-5 mr-5">
    <div class="card-header"><b>Salas alocadas</b></div>
    <div class="card-body">
        <div class="form-row">
            <div class="input-group mb-3 col-md-10">
                <input type="text" class="form-control col-md-4 ml-4 mr-0 border-secondary" placeholder="Buscar" aria-label="Buscar" aria-describedby="Buscar">
                <div class="input-group-append">
                    <button class="btn btn-light border-left-0 border-secondary col-md-11" type="button" id="icon"><i class="fas fa-search"></i></button>
                </div>
            </div>
            <div class="input-group mb-3 col-md-2">
                <button type="submit" onclick="ocultarExibirCalendario()" class="col-md-4 mr-2  btn btn-secondary border-0 text-center" value="Calendario"><i class="fas fa-calendar"></i></button>
                <button type="submit" onclick="ocultarExibirLista()" class="col-md-4 ml-2 mr-5 btn btn-secondary border-0 text-center " value="Lista"><i class="fas fa-list"></i></button>
            </div>
        </div>
<table id="hideLista" class="table table-striped mt-5 col-md-12 table-responsive text-center">
  <thead class="bg-secondary">
    <tr class="col">
      <th scope="col"></th>
      <th scope="col">Sala</th>
      <th scope="col" class="col">Professor(a)</th>
      <th scope="col">Turma</th>
      <th scope="col">Data</th>
      <th scope="col">Horário</th>
      <th scope="col">Ações</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"><input type="checkbox" aria-label="Excluir"></th>
      <td>520</td>
      <td>Professor(a) Marcelo de Carvalho (geo)</td>
      <td>2A</td>
      <td>14/08/2019</td>
      <td>09:05 - 09:55 </td>
      <td><button class="btn btn-outline-light"><i class="fas fa-trash text-danger"></i></button></td>
    </tr>
    <tr>
      <th scope="row"><input type="checkbox" aria-label="Excluir"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td><button class="btn btn-outline-light"><i class="fas fa-trash text-danger"></i></button></td>
    </tr>
    <tr>
      <th scope="row"><input type="checkbox" aria-label="Excluir"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td><button class="btn btn-outline-light"><i class="fas fa-trash text-danger"></i></button></td>
    </tr>
  </tbody>
</table>
    </div>
<!--CALENDARIO-->
<div class="form-row mt-5">
  <div id="hideCalendar" class="form-group col-md-11">
    <div id='calendar' class="col-md-12"></div>
  </div>
</div>
<!-- Footer -->
<footer class="align-bottom fixed-bottom font-small bg-dark text-white">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3"> 2019 © Copyright -
        <a href="#" class="text-white">Reservex</a>
    </div>
    
    <!-- Copyright -->
</footer>
<!-- Footer -->
</body>
</html>