<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../css/fontawesome/css/all.css">
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="shortcut icon" href="../img/logo.png"/>
    <title>RESERVA</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm navbar-light bg-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content"
            aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <a class="navbar-brand text-white" href="index.php">Reservex&nbsp;<i class="fas fa-desktop text-white"></i></a>
        <!-- Links -->
        <div class="collapse navbar-collapse justify-content-end" id="nav-content">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="../internal/addNewReserve.php" class="btn btn-success text-white"><i
                            class="fas fa-plus"></i></a>
                </li>
            </ul>
        </div>
    </nav>
    <!--fim da navbar-->
    <div class="card mt-4 ml-5 mr-5">
        <div class="card-header">
            <b>Minha conta</b>
        </div>
        <div class="card-body">
            <div class="container">
                <div class="row col-md-12 ">
                    <div class="col-sm col-md-5">
                        <div class="form-group">
                            Escola:
                            <input class="form-control mt-2 col-md-6">
                        </div>
                        <div class="form-group">
                            Email:
                            <input class="form-control mt-2 col-md-6">
                        </div>
                    </div>
                    <div class="col-sm col-md-4">
                        <div class="form-group">
                            Telefone:
                            <input class="form-control mt-2 col-md-6">
                        </div>
                        <div class="form-group">
                            Endereço:
                            <input class="form-control mt-2 col-md-6">
                        </div>
                    </div>
                    <div class="col-sm col-md-3">
                            <div class="form-group">
                                    Senha atual:
                                    <input class="form-control mt-2 col-md-6">
                                </div>
                                <div class="form-group">
                                    Nova senha:
                                    <input class="form-control mt-2 col-md-6">
                                </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="../internal/index.php" class="btn btn-secondary float-right">Voltar</a>
            <a href="#" class="btn btn-success">Salvar</a>
        </div>
    </div>
    <!-- Footer -->
    <footer class="align-bottom fixed-bottom font-small bg-dark text-white">
        <!-- Copyright -->
        <div class="footer-copyright text-center py-3"> 2019 © Copyright -
            <a href="#" class="text-white">Reservex</a>
        </div>
        <!-- Copyright -->
    </footer>
    <!-- Footer -->
</body>
</html>